<script>
    let name = '';
    let phone = '';
    let results = [];
  
    async function handleSubmit(event) {
      event.preventDefault();
      await search();
    }
  
    async function search() {
      try {
        let url = 'https://hapi.fhir.org/baseR4/Patient?';
        if (name) {
          url += `_content=${encodeURIComponent(name)}&`;
        }
        if (phone) {
          url += `telecom=${encodeURIComponent(phone)}&`;
        }
        url = url.slice(0, -1); // Remove the trailing "&"
  
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        results = data.entry ? data.entry.map(entry => entry.resource) : [];
      } catch (error) {
        console.error('Error:', error);
        results = [];
      }
    }
  </script>
  
  <form on:submit={handleSubmit}>
    <div>
      <label for="name">Name:</label>
      <input type="text" id="name" bind:value={name} />
    </div>
  
    <div>
      <label for="phone">Phone Number:</label>
      <input type="text" id="phone" bind:value={phone} />
    </div>
  
    <button type="submit">Search</button>
  </form>
  
  {#if results.length > 0}
    <h2>Search Results</h2>
    <ul>
      {#each results as result}
        <li>
          <div><strong>Name:</strong> {result.name && result.name[0] ? result.name[0].given.join(' ') + ' ' + result.name[0].family : 'N/A'}</div>
          <div><strong>Gender:</strong> {result.gender || 'N/A'}</div>
          <div><strong>DOB:</strong> {result.birthDate || 'N/A'}</div>
          <div><strong>Phone:</strong> {result.telecom && result.telecom[0] ? result.telecom[0].value : 'N/A'}</div>
        </li>
      {/each}
    </ul>
  {:else}
    <p>No results found.</p>
  {/if}
  
  <style>
    div {
      margin-top: 1em;
    }
    label {
      display: block;
      margin-bottom: 0.5em;
    }
    input {
      width: 100%;
      padding: 0.5em;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    button {
      padding: 0.7em;
      color: #fff;
      background-color: #007bff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1em;
    }
    button:hover {
      background-color: #0056b3;
    }
    ul {
      list-style-type: none;
      padding: 0;
    }
    li {
      margin: 1em 0;
      padding: 1em;
      border: 1px solid #ccc;
      border-radius: 4px;
      background: #f9f9f9;
    }
  </style>
  