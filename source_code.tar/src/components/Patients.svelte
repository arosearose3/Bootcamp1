<script>
    import PatientList from './PatientList.svelte';
    import AddEditPatient from './AddEditPatient.svelte';
    import { onMount } from 'svelte';
  
    // Define the initial state of existingPatients
    let initialPatients = [
      { name: 'John Doe', gender: 'Male', dob: '1990-01-01', phone: '123-456-7890' },
      { name: 'Jane Smith', gender: 'Female', dob: '1985-05-15', phone: '987-654-3210' }
    ];
  
    let existingPatients = [];
  
    function loadPatients() {
      const savedPatients = localStorage.getItem('existingPatients');
      if (savedPatients) {
        existingPatients = JSON.parse(savedPatients);
      } else {
        existingPatients = [...initialPatients];
        savePatients();
      }
    }
  
    function savePatients() {
      localStorage.setItem('existingPatients', JSON.stringify(existingPatients));
    }
  
    let patients = [];
    let currentComponent = 'patients';
    let selectedPatient = null;
    let patientCount = 0;
    let buttonText = 'Add Patient'; // Initial button text
  
    onMount(() => {
      loadPatients();
    //  get_patient_count();
    });
  
    async function get_patient_count() {
      try {
        const response = await fetch('http://hapi.fhir.org/baseR4/Patient?active=true&_total=accurate&_count=1');
        const data = await response.json();
        patientCount = data.total;
      } catch (error) {
        console.error('Failed to fetch patient count:', error);
      }
    }
  
    function addPatient() {
      selectedPatient = null;
      buttonText = 'Add Patient'; // Reset button text when adding a new patient
      currentComponent = 'addEditPatient';
    }
  
    function editPatient(event) {
      selectedPatient = event.detail;
      buttonText = 'Update Patient'; // Change button text when editing a patient
      currentComponent = 'addEditPatient';
    }
  
    function handlePatientSubmit(event) {
      const newPatients = event.detail;
      patients = newPatients;
      existingPatients = newPatients; // Update existingPatients as well
      savePatients(); // Save to localStorage
      currentComponent = 'patients';
      get_patient_count(); // Update the patient count after adding/updating a patient
    }
  
    function handleUpdatePatients(event) {
      existingPatients = event.detail;
      patients = existingPatients;
      savePatients(); // Save to localStorage
    }
  
    function handleCancel() {
      currentComponent = 'patients';
    }
  </script>
  
  <div>
    <div class="header">
      <label>Total Patients: {patientCount}</label>
      <button on:click={get_patient_count}>Refresh Count</button>
    </div>
    <button on:click={addPatient}>{buttonText}</button> <!-- Use buttonText for the button label -->
    {#if currentComponent === 'patients'}
      <PatientList {existingPatients} on:edit={editPatient} />
    {:else if currentComponent === 'addEditPatient'}
      <AddEditPatient on:submit={handlePatientSubmit} on:cancel={handleCancel} on:updatePatients={handleUpdatePatients} {selectedPatient} {existingPatients} />
    {/if}
    <br>
    <pre>{JSON.stringify(existingPatients, null, 2)}</pre>
  </div>
  
  <style>
    .header {
      display: flex;
      align-items: center;
      margin-bottom: 1em;
    }
  
    .header label {
      font-weight: bold;
      margin-right: 1em;
    }
  
    div {
      margin-top: 1em;
    }
  
    button {
      margin-bottom: 1em;
      margin-right: 1em; /* Ensure space between buttons */
    }
  </style>
  