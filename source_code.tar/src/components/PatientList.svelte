<script>
    import { createEventDispatcher } from 'svelte';
  
    export let existingPatients = [];
    const dispatch = createEventDispatcher();
  
    let sortedPatients = [];
    let sortColumn = 'name';
    let sortDirection = 'asc';
  
    $: sortedPatients = sortPatients(existingPatients, sortColumn, sortDirection);
  
    function sortPatients(patients, column, direction) {
        console.log("sorting patients", patients, column, direction);

      return [...patients].sort((a, b) => {
        if (a[column] < b[column]) {
          return direction === 'asc' ? -1 : 1;
        } else if (a[column] > b[column]) {
          return direction === 'asc' ? 1 : -1;
        } else {
          return 0;
        }
      });
    }
  
    function sortBy(column) {
      if (sortColumn === column) {
        sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
      } else {
        sortColumn = column;
        sortDirection = 'asc';
      }
    }
  
    function editPatient(patient) {
      dispatch('edit', patient);
    }
  
    function getSortIndicator(column) {
      if (column === sortColumn) {
        return sortDirection === 'asc' ? '↑' : '↓';
      }
      return '';
    }
  </script>
  
  <table>
    <thead>
      <tr>
        <th on:click={() => sortBy('name')}>Name {getSortIndicator('name')}</th>
        <th on:click={() => sortBy('gender')}>Gender {getSortIndicator('gender')}</th>
        <th on:click={() => sortBy('dob')}>DOB {getSortIndicator('dob')}</th>
        <th on:click={() => sortBy('phone')}>Phone {getSortIndicator('phone')}</th>
      </tr>
    </thead>
    <tbody>
      {#each sortedPatients as patient}
        <tr on:click={() => editPatient(patient)} class="patient-row">
          <td>{patient.name}</td>
          <td>{patient.gender}</td>
          <td>{patient.dob}</td>
          <td>{patient.phone}</td>
        </tr>
      {/each}
    </tbody>
  </table>
  
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 1em;
    }
  
    th, td {
      padding: 0.5em;
      border: 1px solid #ccc;
      text-align: left;
    }
  
    th {
      cursor: pointer;
      background-color: #f9f9f9;
    }
  
    th:hover {
      background-color: #e9e9e9;
    }
  
    .patient-row:hover {
      background-color: #f1f1f1;
    }
  
    .sort-indicator {
      margin-left: 5px;
    }
  </style>
  