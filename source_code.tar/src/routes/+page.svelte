<script>
    import Patients from '../components/Patients.svelte';
    import SearchPatient from '../components/SearchPatient.svelte';
  
    let currentView = 'patients';

    function showPatients() {
    currentView = 'patients';
    }

    function showSearch() {
      currentView = 'search';
    }
  </script>
  
  <nav>
    <button on:click={showPatients}>Patients</button>
    <button on:click={showSearch}>Search</button>
  </nav>
  
  <main>
    {#if currentView === 'patients'}
      <Patients />
    {:else if currentView === 'search'}
      <SearchPatient />
    {/if}
  </main>
  
  <style>
    nav {
      background-color: #333;
      padding: 1em;
    }
    button {
      color: white;
      background: none;
      border: none;
      margin-right: 1em;
      cursor: pointer;
      font-size: 1em;
    }
    main {
      padding: 2em;
    }
  </style>
  